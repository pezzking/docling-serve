import logging
from functools import lru_cache

from docling.models.factories.layout_factory import LayoutFactory
from docling.models.factories.ocr_factory import OcrFactory
from docling.models.factories.picture_description_factory import (
    PictureDescriptionFactory,
)
from docling.models.factories.table_factory import TableStructureFactory

logger = logging.getLogger(__name__)


@lru_cache(maxsize=4)
def get_ocr_factory(allow_external_plugins: bool = False) -> OcrFactory:
    factory = OcrFactory()
    factory.load_from_plugins(allow_external_plugins=allow_external_plugins)
    logger.info("Registered ocr engines: %r", factory.registered_kind)
    return factory


@lru_cache(maxsize=4)
def get_picture_description_factory(
    allow_external_plugins: bool = False,
) -> PictureDescriptionFactory:
    factory = PictureDescriptionFactory()
    factory.load_from_plugins(allow_external_plugins=allow_external_plugins)
    logger.info("Registered picture descriptions: %r", factory.registered_kind)
    return factory


@lru_cache(maxsize=4)
def get_layout_factory(allow_external_plugins: bool = False) -> LayoutFactory:
    factory = LayoutFactory()
    factory.load_from_plugins(allow_external_plugins=allow_external_plugins)
    logger.info("Registered layout engines: %r", factory.registered_kind)
    return factory


@lru_cache(maxsize=4)
def get_table_structure_factory(
    allow_external_plugins: bool = False,
) -> TableStructureFactory:
    factory = TableStructureFactory()
    factory.load_from_plugins(allow_external_plugins=allow_external_plugins)
    logger.info("Registered table structure engines: %r", factory.registered_kind)
    return factory
